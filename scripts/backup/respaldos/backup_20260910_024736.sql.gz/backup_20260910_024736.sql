-- Backup de clinica_dental
-- Generado: 2026-09-10 02:47:36

SET FOREIGN_KEY_CHECKS=0;
SET NAMES utf8mb4;

-- Estructura de `alertas_internas_preferencias`
DROP TABLE IF EXISTS `alertas_internas_preferencias`;
CREATE TABLE `alertas_internas_preferencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `alertas_internas_preferencias`
INSERT INTO `alertas_internas_preferencias` (`id`, `nombre`, `descripcion`, `activo`) VALUES ('1', 'Nueva cita agendada', 'Notificar al dentista asignado cuando se agenda una cita', '1');
INSERT INTO `alertas_internas_preferencias` (`id`, `nombre`, `descripcion`, `activo`) VALUES ('2', 'Cita cancelada por paciente', 'Alertar al equipo cuando un paciente cancela', '1');
INSERT INTO `alertas_internas_preferencias` (`id`, `nombre`, `descripcion`, `activo`) VALUES ('3', 'Pago pendiente de verificación', 'Alertar cuando el paciente sube comprobante de pago', '1');
INSERT INTO `alertas_internas_preferencias` (`id`, `nombre`, `descripcion`, `activo`) VALUES ('4', 'Material / Insumo bajo stock', 'Recordatorio cuando algún insumo está por agotarse', '1');

-- Estructura de `citas`
DROP TABLE IF EXISTS `citas`;
CREATE TABLE `citas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `servicio_id` int(11) NOT NULL,
  `tratamiento_id` int(11) DEFAULT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `consultorio` varchar(50) DEFAULT NULL,
  `estado` enum('pendiente','confirmada','completada','cancelada') NOT NULL DEFAULT 'pendiente',
  `notas` text DEFAULT NULL,
  `diagnostico` text DEFAULT NULL,
  `indicaciones` text DEFAULT NULL,
  `costo` decimal(10,2) NOT NULL DEFAULT 0.00,
  `pagado` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `servicio_id` (`servicio_id`),
  KEY `fk_citas_tratamiento` (`tratamiento_id`),
  CONSTRAINT `citas_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `citas_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctores` (`id`),
  CONSTRAINT `citas_ibfk_3` FOREIGN KEY (`servicio_id`) REFERENCES `servicios` (`id`),
  CONSTRAINT `fk_citas_tratamiento` FOREIGN KEY (`tratamiento_id`) REFERENCES `tratamientos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `citas`
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('1', '1', '1', '1', NULL, '2026-07-30', '15:10:00', 'Consultorio 1', 'pendiente', '', NULL, NULL, '400.00', '1', '2026-07-30 11:06:15');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('2', '1', '1', '1', NULL, '2026-08-10', '09:00:00', 'Consultorio 1', 'completada', '', NULL, NULL, '400.00', '1', '2026-07-31 21:27:10');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('3', '1', '1', '1', NULL, '2026-08-06', '08:38:00', 'Consultorio 1', 'cancelada', '', NULL, NULL, '400.00', '0', '2026-08-03 18:39:13');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('4', '4', '1', '1', NULL, '2026-08-13', '10:20:00', 'Consultorio 1', 'confirmada', '', NULL, NULL, '400.00', '1', '2026-08-06 13:02:12');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('5', '4', '1', '1', NULL, '2026-08-13', '13:00:00', 'Consultorio 1', 'pendiente', '', NULL, NULL, '400.00', '1', '2026-08-06 13:03:25');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('6', '2', '1', '2', NULL, '2026-08-12', '10:20:00', 'Consultorio 1', 'confirmada', '', NULL, NULL, '350.00', '0', '2026-08-06 13:13:44');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('7', '1', '1', '2', NULL, '2026-08-10', '13:00:00', 'Consultorio 1', 'pendiente', '', NULL, NULL, '350.00', '0', '2026-08-06 13:16:37');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('8', '5', '1', '2', NULL, '2026-08-18', '08:00:00', 'Consultorio 1', 'cancelada', '', NULL, NULL, '350.00', '1', '2026-08-14 17:53:59');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('9', '1', '1', '1', '3', '2026-08-14', '19:21:00', 'Consultorio 1', 'cancelada', 'Primera sesión — creada automáticamente al asignar el tratamiento.', NULL, NULL, '400.00', '0', '2026-08-14 19:22:02');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('10', '3', '1', '1', '4', '2026-08-17', '18:20:00', 'Consultorio 1', 'pendiente', 'Primera sesión — creada automáticamente al asignar el tratamiento.', NULL, NULL, '400.00', '0', '2026-08-14 19:23:19');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('11', '4', '1', '1', NULL, '2026-08-17', '09:00:00', 'Consultorio 1', 'completada', '', NULL, NULL, '400.00', '1', '2026-08-14 19:24:39');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('12', '1', '1', '2', '5', '2026-08-18', '13:00:00', 'Consultorio 1', 'cancelada', 'Primera sesión — creada automáticamente al asignar el tratamiento.', NULL, NULL, '350.00', '0', '2026-08-14 19:27:47');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('13', '2', '1', '2', '8', '2026-08-17', '08:30:00', 'Consultorio 1', 'completada', 'Primera sesión — creada automáticamente al asignar el tratamiento.', NULL, NULL, '350.00', '0', '2026-08-14 20:45:10');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('14', '2', '1', '1', '11', '2026-08-17', '10:00:00', 'Consultorio 1', 'pendiente', 'Primera sesión — creada automáticamente al asignar el tratamiento.', NULL, NULL, '400.00', '0', '2026-08-16 16:01:28');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('15', '5', '1', '1', '12', '2026-08-19', '11:46:00', 'Consultorio 1', 'cancelada', 'Primera sesión — creada automáticamente al asignar el tratamiento.', NULL, NULL, '400.00', '0', '2026-08-19 20:46:41');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('20', '5', '1', '1', '17', '2026-08-21', '08:00:00', 'Consultorio 1', 'cancelada', 'Primera sesión — creada automáticamente al asignar el tratamiento.', NULL, NULL, '400.00', '0', '2026-08-20 22:28:27');
INSERT INTO `citas` (`id`, `paciente_id`, `doctor_id`, `servicio_id`, `tratamiento_id`, `fecha`, `hora`, `consultorio`, `estado`, `notas`, `diagnostico`, `indicaciones`, `costo`, `pagado`, `fecha_creacion`) VALUES ('21', '5', '1', '2', '18', '2026-08-24', '08:20:00', 'Consultorio 1', 'cancelada', 'Primera sesión — creada automáticamente al asignar el tratamiento.', NULL, NULL, '350.00', '0', '2026-08-20 22:30:12');

-- Estructura de `configuracion_canales`
DROP TABLE IF EXISTS `configuracion_canales`;
CREATE TABLE `configuracion_canales` (
  `id` int(11) NOT NULL DEFAULT 1,
  `email_activo` tinyint(1) NOT NULL DEFAULT 1,
  `email_remitente` varchar(150) DEFAULT NULL,
  `email_nombre_remitente` varchar(150) DEFAULT NULL,
  `email_asunto` varchar(255) DEFAULT 'Recordatorio de tu cita',
  `whatsapp_activo` tinyint(1) NOT NULL DEFAULT 0,
  `whatsapp_numero` varchar(30) DEFAULT NULL,
  `whatsapp_remitente` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `configuracion_canales`
INSERT INTO `configuracion_canales` (`id`, `email_activo`, `email_remitente`, `email_nombre_remitente`, `email_asunto`, `whatsapp_activo`, `whatsapp_numero`, `whatsapp_remitente`) VALUES ('1', '1', 'recordatorios@dentalcare.mx', 'DentalCare', 'Recordatorio de tu cita en DentalCare', '0', NULL, NULL);

-- Estructura de `configuracion_clinica`
DROP TABLE IF EXISTS `configuracion_clinica`;
CREATE TABLE `configuracion_clinica` (
  `id` int(11) NOT NULL DEFAULT 1,
  `nombre` varchar(150) DEFAULT NULL,
  `slogan` varchar(200) DEFAULT NULL,
  `telefono_principal` varchar(30) DEFAULT NULL,
  `telefono_emergencia` varchar(30) DEFAULT NULL,
  `correo` varchar(150) DEFAULT NULL,
  `sitio_web` varchar(150) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `ciudad` varchar(100) DEFAULT NULL,
  `estado_provincia` varchar(100) DEFAULT NULL,
  `codigo_postal` varchar(15) DEFAULT NULL,
  `pais` varchar(80) DEFAULT NULL,
  `rfc` varchar(30) DEFAULT NULL,
  `razon_social` varchar(150) DEFAULT NULL,
  `moneda` varchar(10) DEFAULT 'MXN',
  `iva_porcentaje` decimal(5,2) DEFAULT 16.00,
  `duracion_cita_default_min` int(11) DEFAULT 30,
  `intervalo_citas_min` int(11) DEFAULT 15,
  `anticipacion_max_dias` int(11) DEFAULT 90,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `configuracion_clinica`
INSERT INTO `configuracion_clinica` (`id`, `nombre`, `slogan`, `telefono_principal`, `telefono_emergencia`, `correo`, `sitio_web`, `direccion`, `ciudad`, `estado_provincia`, `codigo_postal`, `pais`, `rfc`, `razon_social`, `moneda`, `iva_porcentaje`, `duracion_cita_default_min`, `intervalo_citas_min`, `anticipacion_max_dias`) VALUES ('1', 'DentalCare Clínica Odontológica', 'Tu sonrisa, nuestra prioridad', '+1 (555) 234-5678', '+1 (555) 999-0000', 'contacto@dentalcare.com', 'www.dentalcare.com', 'Av. Principal 1234, Col. Centro', 'Ciudad de México', 'CDMX', '06600', 'México', 'DCO123456ABC', 'DentalCare S.A. de C.V.', 'MXN', '16.00', '30', '15', '90');

-- Estructura de `consentimientos`
DROP TABLE IF EXISTS `consentimientos`;
CREATE TABLE `consentimientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `tratamiento_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `texto` text NOT NULL,
  `estado` enum('pendiente','firmado','rechazado') NOT NULL DEFAULT 'pendiente',
  `firma` varchar(150) DEFAULT NULL,
  `firmado_por` enum('doctor','paciente') DEFAULT NULL,
  `fecha` date NOT NULL,
  `fecha_firma` datetime DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `fk_consentimientos_tratamiento` (`tratamiento_id`),
  CONSTRAINT `consentimientos_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `consentimientos_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctores` (`id`),
  CONSTRAINT `fk_consentimientos_tratamiento` FOREIGN KEY (`tratamiento_id`) REFERENCES `tratamientos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `consentimientos`
INSERT INTO `consentimientos` (`id`, `paciente_id`, `tratamiento_id`, `doctor_id`, `tipo`, `titulo`, `texto`, `estado`, `firma`, `firmado_por`, `fecha`, `fecha_firma`, `fecha_creacion`) VALUES ('1', '1', NULL, '1', 'extraccion', 'Extracción Dental', 'CONSENTIMIENTO INFORMADO PARA EXTRACCIÓN DENTAL\n\nEl/la paciente declara haber sido informado/a sobre el procedimiento de extracción dental, incluyendo:\n\n1. DESCRIPCIÓN DEL PROCEDIMIENTO: La extracción dental consiste en la remoción del diente de su alvéolo mediante instrumentos específicos, bajo anestesia local.\n\n2. RIESGOS Y COMPLICACIONES POSIBLES: Dolor, inflamación, sangrado, infección, y en casos poco frecuentes, daño a estructuras vecinas.\n\n3. ALTERNATIVAS DE TRATAMIENTO: Se han explicado alternativas cuando aplican.\n\nEl/la paciente firma en señal de haber comprendido la información anterior.', 'firmado', 'Erick', 'doctor', '2026-08-02', '2026-08-01 21:28:02', '2026-08-01 21:27:36');
INSERT INTO `consentimientos` (`id`, `paciente_id`, `tratamiento_id`, `doctor_id`, `tipo`, `titulo`, `texto`, `estado`, `firma`, `firmado_por`, `fecha`, `fecha_firma`, `fecha_creacion`) VALUES ('2', '2', NULL, '1', 'ortodoncia', 'Ortodoncia', 'CONSENTIMIENTO INFORMADO PARA ORTODONCIA\n\nEl/la paciente declara haber sido informado/a sobre el tratamiento de ortodoncia, incluyendo:\n\n1. DESCRIPCIÓN DEL PROCEDIMIENTO: Uso de brackets o alineadores para corregir la posición dental a lo largo de un tratamiento prolongado.\n\n2. RIESGOS Y COMPLICACIONES POSIBLES: Molestia inicial, reabsorción radicular leve, necesidad de cooperación del paciente para el éxito del tratamiento.\n\n3. DURACIÓN ESTIMADA: Variable según el caso clínico.\n\nEl/la paciente firma en señal de haber comprendido la información anterior.', 'rechazado', NULL, 'doctor', '2026-08-02', '2026-08-01 21:28:44', '2026-08-01 21:28:41');
INSERT INTO `consentimientos` (`id`, `paciente_id`, `tratamiento_id`, `doctor_id`, `tipo`, `titulo`, `texto`, `estado`, `firma`, `firmado_por`, `fecha`, `fecha_firma`, `fecha_creacion`) VALUES ('3', '2', NULL, '1', 'endodoncia', 'Endodoncia', 'CONSENTIMIENTO INFORMADO PARA ENDODONCIA\n\nEl/la paciente declara haber sido informado/a sobre el tratamiento de conductos radiculares, incluyendo:\n\n1. DESCRIPCIÓN DEL PROCEDIMIENTO: Limpieza, desinfección y sellado del sistema de conductos del diente afectado.\n\n2. RIESGOS Y COMPLICACIONES POSIBLES: Dolor posterior al tratamiento, posible fractura de instrumental, necesidad de retratamiento.\n\n3. ALTERNATIVAS: Extracción del diente como alternativa.\n\nEl/la paciente firma en señal de haber comprendido la información anterior.', 'firmado', 'Maria', 'doctor', '2026-08-16', '2026-08-18 11:25:31', '2026-08-16 15:58:45');
INSERT INTO `consentimientos` (`id`, `paciente_id`, `tratamiento_id`, `doctor_id`, `tipo`, `titulo`, `texto`, `estado`, `firma`, `firmado_por`, `fecha`, `fecha_firma`, `fecha_creacion`) VALUES ('4', '1', NULL, '1', 'blanqueamiento', 'Blanqueamiento Dental', 'CONSENTIMIENTO INFORMADO PARA BLANQUEAMIENTO DENTAL\n\nEl/la paciente declara haber sido informado/a sobre el tratamiento de blanqueamiento dental, incluyendo:\n\n1. DESCRIPCIÓN DEL PROCEDIMIENTO: Aplicación de agente blanqueador sobre la superficie dental.\n\n2. RIESGOS Y COMPLICACIONES POSIBLES: Sensibilidad dental temporal, irritación gingival leve.\n\n3. RESULTADOS: El resultado puede variar según el caso y no es permanente.\n\nEl/la paciente firma en señal de haber comprendido la información anterior.', 'firmado', 'aaa', 'paciente', '2026-08-18', '2026-08-19 20:37:45', '2026-08-18 11:25:51');
INSERT INTO `consentimientos` (`id`, `paciente_id`, `tratamiento_id`, `doctor_id`, `tipo`, `titulo`, `texto`, `estado`, `firma`, `firmado_por`, `fecha`, `fecha_firma`, `fecha_creacion`) VALUES ('5', '2', NULL, '1', 'endodoncia', 'Endodoncia', 'CONSENTIMIENTO INFORMADO PARA ENDODONCIA\n\nEl/la paciente declara haber sido informado/a sobre el tratamiento de conductos radiculares, incluyendo:\n\n1. DESCRIPCIÓN DEL PROCEDIMIENTO: Limpieza, desinfección y sellado del sistema de conductos del diente afectado.\n\n2. RIESGOS Y COMPLICACIONES POSIBLES: Dolor posterior al tratamiento, posible fractura de instrumental, necesidad de retratamiento.\n\n3. ALTERNATIVAS: Extracción del diente como alternativa.\n\nEl/la paciente firma en señal de haber comprendido la información anterior.', 'rechazado', NULL, 'paciente', '2026-08-19', '2026-08-19 20:42:43', '2026-08-18 20:29:23');
INSERT INTO `consentimientos` (`id`, `paciente_id`, `tratamiento_id`, `doctor_id`, `tipo`, `titulo`, `texto`, `estado`, `firma`, `firmado_por`, `fecha`, `fecha_firma`, `fecha_creacion`) VALUES ('6', '5', NULL, '1', 'ortodoncia', 'Ortodoncia', 'CONSENTIMIENTO INFORMADO PARA ORTODONCIA\n\nEl/la paciente declara haber sido informado/a sobre el tratamiento de ortodoncia, incluyendo:\n\n1. DESCRIPCIÓN DEL PROCEDIMIENTO: Uso de brackets o alineadores para corregir la posición dental a lo largo de un tratamiento prolongado.\n\n2. RIESGOS Y COMPLICACIONES POSIBLES: Molestia inicial, reabsorción radicular leve, necesidad de cooperación del paciente para el éxito del tratamiento.\n\n3. DURACIÓN ESTIMADA: Variable según el caso clínico.\n\nEl/la paciente firma en señal de haber comprendido la información anterior.', 'firmado', 'sa', 'paciente', '2026-08-20', '2026-08-19 20:52:21', '2026-08-19 20:47:54');
INSERT INTO `consentimientos` (`id`, `paciente_id`, `tratamiento_id`, `doctor_id`, `tipo`, `titulo`, `texto`, `estado`, `firma`, `firmado_por`, `fecha`, `fecha_firma`, `fecha_creacion`) VALUES ('7', '1', NULL, '1', 'extraccion', 'Extracción Dental', 'CONSENTIMIENTO INFORMADO PARA EXTRACCIÓN DENTAL\n\nEl/la paciente declara haber sido informado/a sobre el procedimiento de extracción dental, incluyendo:\n\n1. DESCRIPCIÓN DEL PROCEDIMIENTO: La extracción dental consiste en la remoción del diente de su alvéolo mediante instrumentos específicos, bajo anestesia local.\n\n2. RIESGOS Y COMPLICACIONES POSIBLES: Dolor, inflamación, sangrado, infección, y en casos poco frecuentes, daño a estructuras vecinas.\n\n3. ALTERNATIVAS DE TRATAMIENTO: Se han explicado alternativas cuando aplican.\n\nEl/la paciente firma en señal de haber comprendido la información anterior.', 'rechazado', NULL, 'paciente', '2026-08-20', '2026-08-19 20:57:29', '2026-08-19 20:57:10');
INSERT INTO `consentimientos` (`id`, `paciente_id`, `tratamiento_id`, `doctor_id`, `tipo`, `titulo`, `texto`, `estado`, `firma`, `firmado_por`, `fecha`, `fecha_firma`, `fecha_creacion`) VALUES ('8', '5', '17', '1', 'personalizado', 'Consentimiento Informado — Blanquamiento dental', 'CONSENTIMIENTO INFORMADO PARA BLANQUAMIENTO DENTAL\n\nEl/la paciente declara haber sido informado/a sobre el tratamiento de Blanquamiento dental, incluyendo:\n\n1. DESCRIPCIÓN DEL PROCEDIMIENTO: [Describe aquí en qué consiste el procedimiento]\n\n2. RIESGOS Y COMPLICACIONES POSIBLES: [Describe aquí los riesgos relevantes para este caso]\n\n3. ALTERNATIVAS DE TRATAMIENTO: [Describe alternativas si aplican]\n\nEl/la paciente firma en señal de haber comprendido la información anterior.', 'rechazado', NULL, 'paciente', '2026-08-21', '2026-08-20 22:33:39', '2026-08-20 22:28:27');
INSERT INTO `consentimientos` (`id`, `paciente_id`, `tratamiento_id`, `doctor_id`, `tipo`, `titulo`, `texto`, `estado`, `firma`, `firmado_por`, `fecha`, `fecha_firma`, `fecha_creacion`) VALUES ('9', '5', '18', '1', 'implante', 'Implante Dental', 'CONSENTIMIENTO INFORMADO PARA IMPLANTE DENTAL\n\nEl/la paciente declara haber sido informado/a sobre la colocación de implante dental, incluyendo:\n\n1. DESCRIPCIÓN DEL PROCEDIMIENTO: Colocación quirúrgica de un implante de titanio en el hueso maxilar/mandibular.\n\n2. RIESGOS Y COMPLICACIONES POSIBLES: Infección, rechazo del implante, daño a estructuras vecinas, fracaso de osteointegración.\n\n3. CUIDADOS POSTERIORES: Se han explicado los cuidados necesarios tras la cirugía.\n\nEl/la paciente firma en señal de haber comprendido la información anterior.', 'rechazado', NULL, 'paciente', '2026-08-21', '2026-08-20 22:42:57', '2026-08-20 22:30:12');

-- Estructura de `doctores`
DROP TABLE IF EXISTS `doctores`;
CREATE TABLE `doctores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `especialidad` varchar(120) DEFAULT NULL,
  `consultorio` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `doctores_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `doctores`
INSERT INTO `doctores` (`id`, `usuario_id`, `especialidad`, `consultorio`) VALUES ('1', '1', 'Administración General', 'Consultorio 1');

-- Estructura de `gastos`
DROP TABLE IF EXISTS `gastos`;
CREATE TABLE `gastos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoria` enum('Nomina','Suministros','Equipos','Renta','Servicios','Marketing') NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `proveedor` varchar(150) DEFAULT NULL,
  `fecha` date NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `recurrente` tinyint(1) NOT NULL DEFAULT 0,
  `estado` enum('pendiente','pagado') NOT NULL DEFAULT 'pendiente',
  `notas` text DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `gastos`
INSERT INTO `gastos` (`id`, `categoria`, `descripcion`, `proveedor`, `fecha`, `monto`, `recurrente`, `estado`, `notas`, `fecha_creacion`) VALUES ('1', 'Suministros', 'Resina', 'Juan', '2026-07-31', '300.00', '1', 'pagado', NULL, '2026-07-31 20:38:14');
INSERT INTO `gastos` (`id`, `categoria`, `descripcion`, `proveedor`, `fecha`, `monto`, `recurrente`, `estado`, `notas`, `fecha_creacion`) VALUES ('2', 'Nomina', 'Nomina', NULL, '2026-07-31', '100.00', '0', 'pagado', NULL, '2026-07-31 20:38:52');
INSERT INTO `gastos` (`id`, `categoria`, `descripcion`, `proveedor`, `fecha`, `monto`, `recurrente`, `estado`, `notas`, `fecha_creacion`) VALUES ('3', 'Renta', 'Pago', NULL, '2026-07-31', '50.00', '1', 'pagado', NULL, '2026-07-31 21:19:34');
INSERT INTO `gastos` (`id`, `categoria`, `descripcion`, `proveedor`, `fecha`, `monto`, `recurrente`, `estado`, `notas`, `fecha_creacion`) VALUES ('4', 'Servicios', 'Mantenimiento', 'CFE', '2026-08-21', '3000.00', '0', 'pagado', NULL, '2026-08-21 13:13:37');
INSERT INTO `gastos` (`id`, `categoria`, `descripcion`, `proveedor`, `fecha`, `monto`, `recurrente`, `estado`, `notas`, `fecha_creacion`) VALUES ('5', 'Servicios', 'Luz', 'CFE', '2026-08-21', '300.00', '1', 'pendiente', NULL, '2026-08-21 13:14:47');

-- Estructura de `horarios_atencion`
DROP TABLE IF EXISTS `horarios_atencion`;
CREATE TABLE `horarios_atencion` (
  `dia_semana` tinyint(4) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `hora_inicio` time DEFAULT NULL,
  `hora_fin` time DEFAULT NULL,
  PRIMARY KEY (`dia_semana`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `horarios_atencion`
INSERT INTO `horarios_atencion` (`dia_semana`, `activo`, `hora_inicio`, `hora_fin`) VALUES ('1', '1', '08:00:00', '20:00:00');
INSERT INTO `horarios_atencion` (`dia_semana`, `activo`, `hora_inicio`, `hora_fin`) VALUES ('2', '1', '08:00:00', '20:00:00');
INSERT INTO `horarios_atencion` (`dia_semana`, `activo`, `hora_inicio`, `hora_fin`) VALUES ('3', '1', '08:00:00', '20:00:00');
INSERT INTO `horarios_atencion` (`dia_semana`, `activo`, `hora_inicio`, `hora_fin`) VALUES ('4', '1', '08:00:00', '20:00:00');
INSERT INTO `horarios_atencion` (`dia_semana`, `activo`, `hora_inicio`, `hora_fin`) VALUES ('5', '1', '08:00:00', '20:00:00');
INSERT INTO `horarios_atencion` (`dia_semana`, `activo`, `hora_inicio`, `hora_fin`) VALUES ('6', '0', NULL, NULL);
INSERT INTO `horarios_atencion` (`dia_semana`, `activo`, `hora_inicio`, `hora_fin`) VALUES ('7', '0', NULL, NULL);

-- Estructura de `log_actividad`
DROP TABLE IF EXISTS `log_actividad`;
CREATE TABLE `log_actividad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `modulo` varchar(50) NOT NULL,
  `accion` varchar(255) NOT NULL,
  `detalle` varchar(255) DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `log_actividad_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `log_actividad`
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('1', '1', 'configuracion', 'Actualizó los datos de la clínica', 'DentalCare Clínica Odontológica', '2026-08-03 11:47:56');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('2', '1', 'configuracion', 'Actualizó los horarios de atención', NULL, '2026-08-03 11:47:56');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('3', '1', 'configuracion', 'Desactivó un doctor', 'ID 1', '2026-08-03 11:48:10');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('4', '1', 'configuracion', 'Reactivó un doctor', 'ID 1', '2026-08-03 11:48:11');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('5', '1', 'configuracion', 'Desactivó un doctor', 'ID 1', '2026-08-03 11:48:11');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('6', '1', 'configuracion', 'Reactivó un doctor', 'ID 1', '2026-08-03 11:48:12');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('7', '1', 'configuracion', 'Desactivó un doctor', 'ID 1', '2026-08-03 11:48:37');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('8', '1', 'configuracion', 'Reactivó un doctor', 'ID 1', '2026-08-03 11:48:38');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('9', '1', 'configuracion', 'Cambió su contraseña', NULL, '2026-08-03 11:49:49');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('10', '1', 'configuracion', 'Cambió su contraseña', NULL, '2026-08-03 18:08:52');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('11', '1', 'configuracion', 'Actualizó los datos de la clínica', 'DentalCare Clínica Odontológica', '2026-08-04 09:35:48');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('12', '1', 'configuracion', 'Actualizó los horarios de atención', NULL, '2026-08-04 09:35:48');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('13', '1', 'configuracion', 'Actualizó los datos de la clínica', 'DentalCare Clínica Odontológica', '2026-08-04 09:35:58');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('14', '1', 'configuracion', 'Actualizó los horarios de atención', NULL, '2026-08-04 09:35:58');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('15', '1', 'configuracion', 'Actualizó los datos de la clínica', 'DentalCare Clínica Odontológica', '2026-08-04 09:36:12');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('16', '1', 'configuracion', 'Actualizó los horarios de atención', NULL, '2026-08-04 09:36:12');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('17', '1', 'configuracion', 'Actualizó los datos de la clínica', 'DentalCare Clínica Odontológica', '2026-08-05 19:42:06');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('18', '1', 'configuracion', 'Actualizó los horarios de atención', NULL, '2026-08-05 19:42:06');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('19', '1', 'configuracion', 'Actualizó los datos de la clínica', 'DentalCare Clínica Odontológica', '2026-08-05 19:45:54');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('20', '1', 'configuracion', 'Actualizó los horarios de atención', NULL, '2026-08-05 19:45:55');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('21', '1', 'configuracion', 'Actualizó los datos de la clínica', 'DentalCare Clínica Odontológica', '2026-08-05 19:47:29');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('22', '1', 'configuracion', 'Actualizó los horarios de atención', NULL, '2026-08-05 19:47:29');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('23', '1', 'pacientes', 'Registró un paciente', 'Hector', '2026-08-05 19:54:42');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('24', '1', 'pacientes', 'Registró un paciente', 'Samanta', '2026-08-05 20:03:36');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('25', '1', 'configuracion', 'Actualizó los datos de la clínica', 'DentalCare Clínica Odontológica', '2026-08-06 12:59:07');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('26', '1', 'configuracion', 'Actualizó los horarios de atención', NULL, '2026-08-06 12:59:08');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('27', '1', 'configuracion', 'Actualizó los datos de la clínica', 'DentalCare Clínica Odontológica', '2026-08-06 12:59:25');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('28', '1', 'configuracion', 'Actualizó los horarios de atención', NULL, '2026-08-06 12:59:26');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('29', '1', 'configuracion', 'Actualizó los datos de la clínica', 'DentalCare Clínica Odontológica', '2026-08-06 13:01:03');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('30', '1', 'configuracion', 'Actualizó los horarios de atención', NULL, '2026-08-06 13:01:03');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('31', '1', 'configuracion', 'Actualizó los datos de la clínica', 'DentalCare Clínica Odontológica', '2026-08-06 13:01:31');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('32', '1', 'configuracion', 'Actualizó los horarios de atención', NULL, '2026-08-06 13:01:31');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('33', '1', 'citas', 'Creó una cita', 'Cita #4, 2026-08-13 10:20', '2026-08-06 13:02:12');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('34', '1', 'citas', 'Editó una cita', 'Cita #4', '2026-08-06 13:05:42');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('35', '1', 'finanzas', 'Registró un pago', 'Pago #4 por $4000', '2026-08-06 13:06:28');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('36', '1', 'citas', 'Creó una cita', 'Cita #6, 2026-08-12 10:20', '2026-08-06 13:13:44');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('37', '1', 'pacientes', 'Editó un paciente', 'Erick', '2026-08-08 13:54:42');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('38', NULL, 'auth', 'Solicitó recuperación de contraseña', 'Usuario #6', '2026-08-12 20:02:58');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('39', NULL, 'auth', 'Solicitó recuperación de contraseña', 'Usuario #6', '2026-08-12 20:27:03');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('40', NULL, 'auth', 'Solicitó recuperación de contraseña', 'Usuario #6', '2026-08-13 22:18:56');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('41', '1', 'citas', 'Editó una cita', 'Cita #2', '2026-08-14 17:41:20');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('42', '1', 'finanzas', 'Registró un pago', 'Pago #5 por $350', '2026-08-14 17:55:51');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('43', '1', 'tratamientos', 'Asignó un tratamiento', 'Blanquamiento dental', '2026-08-14 18:29:10');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('44', '1', 'tratamientos', 'Asignó un tratamiento', 'Blanquamiento dental', '2026-08-14 19:22:02');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('45', '1', 'citas', 'Creó una cita (automática por tratamiento)', 'Cita #9, 2026-08-14 19:21', '2026-08-14 19:22:02');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('46', '1', 'tratamientos', 'Asignó un tratamiento', 'Blanquamiento dental', '2026-08-14 19:23:19');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('47', '1', 'citas', 'Creó una cita (automática por tratamiento)', 'Cita #10, 2026-08-17 18:20', '2026-08-14 19:23:20');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('48', '1', 'citas', 'Creó una cita', 'Cita #11, 2026-08-17 09:00', '2026-08-14 19:24:39');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('49', '1', 'citas', 'Editó una cita', 'Cita #11', '2026-08-14 19:25:21');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('50', '1', 'citas', 'Editó una cita', 'Cita #11', '2026-08-14 19:25:31');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('51', '1', 'citas', 'Editó una cita', 'Cita #11', '2026-08-14 19:25:49');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('52', '1', 'citas', 'Editó una cita', 'Cita #8', '2026-08-14 19:26:08');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('53', '1', 'tratamientos', 'Asignó un tratamiento', 'Implante dental', '2026-08-14 19:27:47');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('54', '1', 'citas', 'Creó una cita (automática por tratamiento)', 'Cita #12, 2026-08-18 13:00', '2026-08-14 19:27:47');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('55', '1', 'tratamientos', 'Asignó un tratamiento', 'Implante dental', '2026-08-14 20:45:10');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('56', '1', 'citas', 'Creó una cita (automática por tratamiento)', 'Cita #13, 2026-08-17 08:30', '2026-08-14 20:45:10');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('57', '1', 'pacientes', 'Desactivó un paciente', 'Paciente #5', '2026-08-14 20:48:40');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('58', '1', 'pacientes', 'Reactivó un paciente', 'Paciente #5', '2026-08-14 20:48:50');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('59', '1', 'citas', 'Editó una cita', 'Cita #13', '2026-08-14 20:54:15');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('60', '1', 'tratamientos', 'Sumó una sesión completada', 'Tratamiento #8 (vía cita #13)', '2026-08-14 20:54:15');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('61', '1', 'tratamientos', 'Canceló un tratamiento', 'Tratamiento #4', '2026-08-15 09:41:00');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('62', '1', 'tratamientos', 'Canceló un tratamiento', 'Tratamiento #2', '2026-08-15 09:41:09');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('63', '1', 'citas', 'Canceló una cita', 'Cita #9', '2026-08-15 09:49:17');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('64', '1', 'tratamientos', 'Canceló un tratamiento', 'Tratamiento #1', '2026-08-15 09:49:30');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('65', '1', 'citas', 'Canceló una cita', 'Cita #12', '2026-08-15 09:49:51');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('66', '1', 'citas', 'Editó una cita', 'Cita #2', '2026-08-15 09:50:41');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('67', '1', 'citas', 'Editó una cita', 'Cita #11', '2026-08-15 10:06:40');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('68', '1', 'citas', 'Editó una cita', 'Cita #11', '2026-08-15 10:06:49');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('69', '1', 'odontograma', 'Actualizó el odontograma', 'Paciente #5', '2026-08-16 09:11:08');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('70', '1', 'odontograma', 'Actualizó el odontograma', 'Paciente #3', '2026-08-16 09:11:52');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('71', '1', 'odontograma', 'Actualizó el odontograma', 'Paciente #2', '2026-08-16 09:12:36');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('72', '1', 'odontograma', 'Actualizó el odontograma', 'Paciente #4', '2026-08-16 09:13:24');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('73', '1', 'recordatorios', 'Envió un recordatorio', 'Cita #8, enviado', '2026-08-16 12:23:41');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('74', '1', 'citas', 'Canceló una cita', 'Cita #8', '2026-08-16 15:25:55');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('75', '1', 'finanzas', 'Marcó un gasto como pagado', 'Gasto #3', '2026-08-16 15:26:42');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('76', '1', 'recetas', 'Cambió el estado de una receta a completada', 'Receta #2', '2026-08-16 15:27:24');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('77', '1', 'consentimientos', 'Generó un consentimiento', 'Endodoncia', '2026-08-16 15:58:45');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('78', '1', 'tratamientos', 'Asignó un tratamiento', 'Blanquamiento dental', '2026-08-16 16:01:28');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('79', '1', 'citas', 'Creó una cita (automática por tratamiento)', 'Cita #14, 2026-08-17 10:00', '2026-08-16 16:01:28');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('80', '1', 'tratamientos', 'Canceló un tratamiento', 'Tratamiento #5', '2026-08-16 20:25:50');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('81', '1', 'citas', 'Editó una cita', 'Cita #11', '2026-08-17 13:15:54');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('82', '1', 'tratamientos', 'Canceló un tratamiento', 'Tratamiento #11', '2026-08-17 22:18:09');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('83', '1', 'tratamientos', 'Canceló un tratamiento', 'Tratamiento #3', '2026-08-18 11:20:14');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('84', '1', 'tratamientos', 'Canceló un tratamiento', 'Tratamiento #8', '2026-08-18 11:20:17');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('85', '1', 'consentimientos', 'Firmó un consentimiento', 'Consentimiento #3', '2026-08-18 11:25:31');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('86', '1', 'consentimientos', 'Generó un consentimiento', 'Blanqueamiento Dental', '2026-08-18 11:25:51');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('87', '1', 'consentimientos', 'Generó un consentimiento', 'Endodoncia', '2026-08-18 20:29:23');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('88', '2', 'consentimientos', 'Firmó un consentimiento', 'Consentimiento #4', '2026-08-19 20:37:45');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('89', '3', 'consentimientos', 'Rechazó un consentimiento', 'Consentimiento #5', '2026-08-19 20:42:43');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('90', '1', 'tratamientos', 'Asignó un tratamiento', 'Blanquamiento dental', '2026-08-19 20:46:41');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('91', '1', 'citas', 'Creó una cita (automática por tratamiento)', 'Cita #15, 2026-08-19 11:46', '2026-08-19 20:46:41');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('92', '1', 'consentimientos', 'Generó un consentimiento', 'Ortodoncia', '2026-08-19 20:47:54');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('93', '6', 'consentimientos', 'Firmó un consentimiento', 'Consentimiento #6', '2026-08-19 20:52:22');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('94', '1', 'consentimientos', 'Generó un consentimiento', 'Extracción Dental', '2026-08-19 20:57:10');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('95', '2', 'consentimientos', 'Rechazó un consentimiento', 'Consentimiento #7', '2026-08-19 20:57:29');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('96', '1', 'tratamientos', 'Canceló un tratamiento', 'Tratamiento #12', '2026-08-20 22:04:24');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('97', '1', 'tratamientos', 'Asignó un tratamiento', 'Blanquamiento dental', '2026-08-20 22:28:27');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('98', '1', 'citas', 'Creó una cita (automática por tratamiento)', 'Cita #20, 2026-08-21 08:00', '2026-08-20 22:28:27');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('99', '1', 'consentimientos', 'Generó un consentimiento (automático por tratamiento)', 'Consentimiento Informado — Blanquamiento dental', '2026-08-20 22:28:27');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('100', '1', 'tratamientos', 'Asignó un tratamiento', 'Implante dental', '2026-08-20 22:30:12');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('101', '1', 'citas', 'Creó una cita (automática por tratamiento)', 'Cita #21, 2026-08-24 08:20', '2026-08-20 22:30:12');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('102', '1', 'consentimientos', 'Generó un consentimiento (automático por tratamiento)', 'Implante Dental', '2026-08-20 22:30:12');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('103', '6', 'consentimientos', 'Rechazó un consentimiento', 'Consentimiento #8', '2026-08-20 22:33:39');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('104', '6', 'consentimientos', 'Rechazó un consentimiento', 'Consentimiento #9', '2026-08-20 22:42:57');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('105', '6', 'tratamientos', 'Canceló un tratamiento (consentimiento rechazado)', 'Tratamiento #18', '2026-08-20 22:42:57');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('106', '1', 'citas', 'Canceló una cita', 'Cita #15', '2026-08-20 22:43:40');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('107', '1', 'finanzas', 'Registró un pago', 'Pago #17 por $200', '2026-08-20 22:46:51');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('108', '1', 'finanzas', 'Registró un pago', 'Pago #18 por $5000', '2026-08-20 22:47:23');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('109', '1', 'finanzas', 'Registró un pago', 'Pago #19 por $400', '2026-08-20 22:50:38');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('110', '1', 'finanzas', 'Registró un pago', 'Pago #20 por $400', '2026-08-21 13:12:42');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('111', '1', 'finanzas', 'Registró un gasto', 'Mantenimiento — $3000', '2026-08-21 13:13:37');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('112', '1', 'finanzas', 'Marcó un gasto como pagado', 'Gasto #4', '2026-08-21 13:13:45');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('113', '1', 'finanzas', 'Registró un gasto', 'Luz — $300', '2026-08-21 13:14:47');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('114', '1', 'inventario', 'Creó un producto', 'Penicilina', '2026-08-21 13:21:05');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('115', '1', 'inventario', 'Registró un movimiento de entrada', 'Producto #4, cantidad 20', '2026-08-21 13:25:38');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('116', '1', 'inventario', 'Registró un movimiento de entrada', 'Producto #6, cantidad 20', '2026-08-21 13:26:25');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('117', '1', 'inventario', 'Creó una orden de compra', 'Pedro', '2026-08-21 13:26:58');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('118', '1', 'inventario', 'Cambió el estado de una orden de compra a aprobada', 'Orden #7', '2026-08-21 13:27:10');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('119', '1', 'inventario', 'Creó una orden de compra', 'Raul', '2026-08-21 13:31:00');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('120', '1', 'inventario', 'Cambió el estado de una orden de compra a aprobada', 'Orden #8', '2026-08-21 13:31:08');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('121', '1', 'recetas', 'Generó una receta', 'Diagnóstico: Retiro de muela', '2026-08-21 13:34:21');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('122', '1', 'recetas', 'Cambió el estado de una receta a completada', 'Receta #3', '2026-08-21 17:46:00');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('123', '1', 'recetas', 'Generó una receta', 'Diagnóstico: sas', '2026-08-21 17:46:37');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('124', '1', 'inventario', 'Cambió el estado de una orden de compra a recibida', 'Orden #7', '2026-08-21 18:25:33');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('125', '1', 'inventario', 'Cambió el estado de una orden de compra a recibida', 'Orden #8', '2026-08-21 18:25:37');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('126', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-22 14:19:24');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('127', '1', 'inventario', 'Registró un movimiento de salida', 'Producto #3, cantidad 2', '2026-08-22 14:20:03');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('128', '1', 'configuracion', 'Desactivó un doctor', 'ID 1', '2026-08-23 14:53:07');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('129', '1', 'configuracion', 'Reactivó un doctor', 'ID 1', '2026-08-23 14:53:09');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('130', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:16');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('131', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:17');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('132', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:31');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('133', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:32');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('134', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:33');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('135', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:33');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('136', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:43');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('137', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:43');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('138', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:43');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('139', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:44');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('140', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:46');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('141', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:48');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('142', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:48');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('143', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:53:51');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('144', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:54:00');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('145', '1', 'configuracion', 'Desactivó un doctor', 'ID 1', '2026-08-23 14:54:02');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('146', '1', 'configuracion', 'Reactivó un doctor', 'ID 1', '2026-08-23 14:54:03');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('147', '1', 'configuracion', 'Editó un doctor', 'Manuel Alejandro', '2026-08-23 14:54:12');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('148', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:56:21');
INSERT INTO `log_actividad` (`id`, `usuario_id`, `modulo`, `accion`, `detalle`, `fecha_creacion`) VALUES ('149', '1', 'configuracion', 'Actualizó preferencias de notificaciones', NULL, '2026-08-23 14:56:22');

-- Estructura de `movimientos_inventario`
DROP TABLE IF EXISTS `movimientos_inventario`;
CREATE TABLE `movimientos_inventario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `tipo` enum('entrada','salida','ajuste') NOT NULL,
  `cantidad` int(11) NOT NULL,
  `stock_antes` int(11) NOT NULL,
  `stock_despues` int(11) NOT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `monto` decimal(10,2) DEFAULT NULL,
  `fecha` date NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `producto_id` (`producto_id`),
  KEY `doctor_id` (`doctor_id`),
  CONSTRAINT `movimientos_inventario_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `movimientos_inventario_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctores` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `movimientos_inventario`
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('1', '1', '1', 'salida', '5', '10', '5', NULL, NULL, '2026-08-01', '2026-08-01 12:41:17');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('2', '1', '1', 'salida', '5', '5', '0', NULL, NULL, '2026-08-01', '2026-08-01 12:41:20');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('3', '1', '1', 'salida', '5', '0', '0', NULL, NULL, '2026-08-01', '2026-08-01 12:41:23');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('4', '1', '1', 'salida', '5', '0', '0', 'AAA', NULL, '2026-08-01', '2026-08-01 12:41:26');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('5', '1', '1', 'entrada', '5', '0', '5', 'AAA', NULL, '2026-08-01', '2026-08-01 12:41:29');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('6', '1', '1', 'salida', '5', '5', '0', 'AAA', NULL, '2026-08-01', '2026-08-01 12:41:32');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('7', '1', '1', 'entrada', '6', '0', '6', 'Recepción de orden OC-2026-001', '60.00', '2026-08-01', '2026-08-01 12:44:34');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('8', '1', '1', 'salida', '5', '6', '1', 'Salida', NULL, '2026-08-01', '2026-08-01 12:45:00');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('9', '1', '1', 'salida', '5', '1', '0', 'Salida', NULL, '2026-08-01', '2026-08-01 12:45:04');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('10', '1', '1', 'salida', '5', '0', '0', 'Salida', NULL, '2026-08-01', '2026-08-01 12:45:06');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('11', '1', '1', 'entrada', '20', '0', '20', 'sss', NULL, '2026-08-01', '2026-08-01 12:49:13');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('12', '1', '1', 'entrada', '20', '20', '40', 'sss', NULL, '2026-08-01', '2026-08-01 12:49:17');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('13', '1', '1', 'salida', '40', '40', '0', NULL, NULL, '2026-08-01', '2026-08-01 15:13:28');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('14', '1', '1', 'salida', '30', '0', '0', NULL, NULL, '2026-08-01', '2026-08-01 15:13:35');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('15', '1', '1', 'salida', '20', '0', '0', NULL, NULL, '2026-08-01', '2026-08-01 15:13:41');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('16', '1', '1', 'salida', '10', '0', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:14:22');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('17', '1', '1', 'ajuste', '30', '0', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:14:28');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('18', '1', '1', 'salida', '30', '0', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:14:38');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('19', '1', '1', 'salida', '20', '0', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:14:42');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('20', '1', '1', 'salida', '10', '0', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:14:47');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('21', '2', '1', 'entrada', '10', '0', '10', 'Recepción de orden OC-2026-003', '200.00', '2026-08-01', '2026-08-01 15:47:00');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('22', '2', '1', 'salida', '100', '10', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:47:33');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('23', '2', '1', 'salida', '10', '0', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:47:39');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('24', '2', '1', 'salida', '11', '0', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:47:43');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('25', '2', '1', 'salida', '10', '0', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:48:30');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('26', '2', '1', 'salida', '9', '0', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:48:35');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('27', '2', '1', 'salida', '9', '0', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:48:42');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('28', '2', '1', 'salida', '9', '0', '0', 'aa', NULL, '2026-08-01', '2026-08-01 15:49:14');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('29', '2', '1', 'salida', '10', '0', '0', 'ss', NULL, '2026-08-01', '2026-08-01 15:50:52');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('30', '3', '1', 'salida', '10', '0', '0', 'Mal', NULL, '2026-08-01', '2026-08-01 15:55:28');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('31', '4', '1', 'entrada', '20', '0', '20', 'AAA', NULL, '2026-08-02', '2026-08-01 19:13:56');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('32', '4', '1', 'entrada', '20', '20', '40', NULL, NULL, '2026-08-02', '2026-08-01 19:14:18');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('33', '4', '1', 'salida', '3', '40', '37', NULL, NULL, '2026-08-02', '2026-08-01 19:15:10');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('34', '4', '1', 'salida', '37', '37', '0', NULL, NULL, '2026-08-02', '2026-08-01 19:15:43');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('35', '4', '1', 'entrada', '10', '0', '10', 'Recepción de orden OC-2026-004', '250.00', '2026-08-01', '2026-08-01 19:16:44');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('36', '4', '1', 'salida', '10', '10', '0', NULL, NULL, '2026-08-02', '2026-08-01 19:17:04');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('37', '4', '1', 'entrada', '1', '0', '1', 'Recepción de orden OC-2026-005', '25.00', '2026-08-01', '2026-08-01 19:18:32');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('38', '4', '1', 'salida', '1', '1', '0', NULL, NULL, '2026-08-02', '2026-08-01 19:18:47');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('39', '5', '1', 'entrada', '5', '0', '5', 'Recepción de orden OC-2026-006', '150.00', '2026-08-01', '2026-08-01 19:21:10');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('40', '5', '1', 'salida', '5', '5', '0', NULL, NULL, '2026-08-02', '2026-08-01 19:21:28');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('41', '4', '1', 'entrada', '20', '0', '20', NULL, NULL, '2026-08-21', '2026-08-21 13:25:38');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('42', '6', '1', 'entrada', '20', '0', '20', NULL, NULL, '2026-08-21', '2026-08-21 13:26:25');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('43', '1', '1', 'entrada', '1', '0', '1', 'Recepción de orden OC-2026-007', '10.00', '2026-08-21', '2026-08-21 18:25:33');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('44', '3', '1', 'entrada', '2', '0', '2', 'Recepción de orden OC-2026-008', '400.00', '2026-08-21', '2026-08-21 18:25:37');
INSERT INTO `movimientos_inventario` (`id`, `producto_id`, `doctor_id`, `tipo`, `cantidad`, `stock_antes`, `stock_despues`, `motivo`, `monto`, `fecha`, `fecha_creacion`) VALUES ('45', '3', '1', 'salida', '2', '2', '0', NULL, NULL, '2026-08-22', '2026-08-22 14:20:03');

-- Estructura de `notificaciones`
DROP TABLE IF EXISTS `notificaciones`;
CREATE TABLE `notificaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(150) NOT NULL,
  `titulo` varchar(150) NOT NULL,
  `mensaje` varchar(255) DEFAULT NULL,
  `paciente_id` int(11) DEFAULT NULL,
  `cita_id` int(11) DEFAULT NULL,
  `leida` tinyint(1) NOT NULL DEFAULT 0,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `cita_id` (`cita_id`),
  CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `notificaciones_ibfk_2` FOREIGN KEY (`cita_id`) REFERENCES `citas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `notificaciones`
INSERT INTO `notificaciones` (`id`, `tipo`, `titulo`, `mensaje`, `paciente_id`, `cita_id`, `leida`, `fecha_creacion`) VALUES ('1', 'Recordatorio de cita (24h antes)', 'Cita en 24 horas', 'Erick — Blanquamiento dental mañana a las 08:38', '1', '3', '1', '2026-08-05 19:31:00');
INSERT INTO `notificaciones` (`id`, `tipo`, `titulo`, `mensaje`, `paciente_id`, `cita_id`, `leida`, `fecha_creacion`) VALUES ('2', 'Recordatorio de cita (24h antes)', 'Cita en 24 horas', 'Maria — Implante dental mañana a las 10:20', '2', '6', '1', '2026-08-11 18:48:21');
INSERT INTO `notificaciones` (`id`, `tipo`, `titulo`, `mensaje`, `paciente_id`, `cita_id`, `leida`, `fecha_creacion`) VALUES ('3', 'Recordatorio de cita (24h antes)', 'Cita en 24 horas', 'Maria — Implante dental mañana a las 08:30', '2', '13', '1', '2026-08-16 09:09:29');
INSERT INTO `notificaciones` (`id`, `tipo`, `titulo`, `mensaje`, `paciente_id`, `cita_id`, `leida`, `fecha_creacion`) VALUES ('4', 'Recordatorio de cita (24h antes)', 'Cita en 24 horas', 'Samanta — Blanquamiento dental mañana a las 09:00', '4', '11', '1', '2026-08-16 09:09:29');
INSERT INTO `notificaciones` (`id`, `tipo`, `titulo`, `mensaje`, `paciente_id`, `cita_id`, `leida`, `fecha_creacion`) VALUES ('5', 'Recordatorio de cita (24h antes)', 'Cita en 24 horas', 'Maria — Blanquamiento dental mañana a las 10:00', '2', '14', '1', '2026-08-16 16:01:31');
INSERT INTO `notificaciones` (`id`, `tipo`, `titulo`, `mensaje`, `paciente_id`, `cita_id`, `leida`, `fecha_creacion`) VALUES ('6', 'Recordatorio de cita (24h antes)', 'Cita en 24 horas', 'Hector — Blanquamiento dental mañana a las 18:20', '3', '10', '1', '2026-08-16 19:09:48');
INSERT INTO `notificaciones` (`id`, `tipo`, `titulo`, `mensaje`, `paciente_id`, `cita_id`, `leida`, `fecha_creacion`) VALUES ('7', 'Recordatorio de cita (24h antes)', 'Cita en 24 horas', 'Alejandro — Blanquamiento dental mañana a las 08:00', '5', '20', '1', '2026-08-20 22:28:32');

-- Estructura de `notificaciones_preferencias`
DROP TABLE IF EXISTS `notificaciones_preferencias`;
CREATE TABLE `notificaciones_preferencias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `evento` varchar(150) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `email` tinyint(1) NOT NULL DEFAULT 1,
  `app` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `notificaciones_preferencias`
INSERT INTO `notificaciones_preferencias` (`id`, `evento`, `descripcion`, `email`, `app`) VALUES ('1', 'Recordatorio de cita (24h antes)', 'Enviar recordatorio al paciente 24 horas antes de su cita', '0', '1');
INSERT INTO `notificaciones_preferencias` (`id`, `evento`, `descripcion`, `email`, `app`) VALUES ('2', 'Recordatorio de cita (2h antes)', 'Enviar un segundo recordatorio 2 horas antes de la cita', '0', '0');
INSERT INTO `notificaciones_preferencias` (`id`, `evento`, `descripcion`, `email`, `app`) VALUES ('7', 'Seguimiento post-tratamiento', 'Mensaje automático de seguimiento después del tratamiento', '0', '0');

-- Estructura de `odontograma`
DROP TABLE IF EXISTS `odontograma`;
CREATE TABLE `odontograma` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `numero_diente` tinyint(4) NOT NULL,
  `condicion` enum('sano','caries','obturado','extraido','implante','corona','endodoncia','fractura') NOT NULL DEFAULT 'sano',
  `notas` text DEFAULT NULL,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_paciente_diente` (`paciente_id`,`numero_diente`),
  CONSTRAINT `odontograma_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `odontograma`
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('1', '1', '1', 'endodoncia', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('2', '1', '2', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('3', '1', '3', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('4', '1', '4', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('5', '1', '5', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('6', '1', '6', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('7', '1', '7', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('8', '1', '8', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('9', '1', '9', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('10', '1', '10', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('11', '1', '11', 'obturado', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('12', '1', '12', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('13', '1', '13', 'fractura', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('14', '1', '14', 'caries', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('15', '1', '15', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('16', '1', '16', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('17', '1', '17', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('18', '1', '18', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('19', '1', '19', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('20', '1', '20', 'corona', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('21', '1', '21', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('22', '1', '22', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('23', '1', '23', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('24', '1', '24', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('25', '1', '25', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('26', '1', '26', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('27', '1', '27', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('28', '1', '28', 'caries', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('29', '1', '29', 'implante', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('30', '1', '30', 'extraido', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('31', '1', '31', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('32', '1', '32', 'sano', NULL, '2026-07-29 17:09:55');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('33', '5', '1', 'corona', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('34', '5', '2', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('35', '5', '3', 'caries', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('36', '5', '4', 'caries', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('37', '5', '5', 'endodoncia', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('38', '5', '6', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('39', '5', '7', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('40', '5', '8', 'caries', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('41', '5', '9', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('42', '5', '10', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('43', '5', '11', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('44', '5', '12', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('45', '5', '13', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('46', '5', '14', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('47', '5', '15', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('48', '5', '16', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('49', '5', '17', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('50', '5', '18', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('51', '5', '19', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('52', '5', '20', 'implante', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('53', '5', '21', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('54', '5', '22', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('55', '5', '23', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('56', '5', '24', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('57', '5', '25', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('58', '5', '26', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('59', '5', '27', 'implante', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('60', '5', '28', 'endodoncia', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('61', '5', '29', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('62', '5', '30', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('63', '5', '31', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('64', '5', '32', 'sano', NULL, '2026-08-16 09:11:08');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('65', '3', '1', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('66', '3', '2', 'implante', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('67', '3', '3', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('68', '3', '4', 'fractura', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('69', '3', '5', 'corona', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('70', '3', '6', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('71', '3', '7', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('72', '3', '8', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('73', '3', '9', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('74', '3', '10', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('75', '3', '11', 'corona', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('76', '3', '12', 'extraido', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('77', '3', '13', 'fractura', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('78', '3', '14', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('79', '3', '15', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('80', '3', '16', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('81', '3', '17', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('82', '3', '18', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('83', '3', '19', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('84', '3', '20', 'caries', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('85', '3', '21', 'fractura', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('86', '3', '22', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('87', '3', '23', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('88', '3', '24', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('89', '3', '25', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('90', '3', '26', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('91', '3', '27', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('92', '3', '28', 'corona', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('93', '3', '29', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('94', '3', '30', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('95', '3', '31', 'implante', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('96', '3', '32', 'sano', NULL, '2026-08-16 09:11:52');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('97', '2', '1', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('98', '2', '2', 'corona', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('99', '2', '3', 'caries', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('100', '2', '4', 'caries', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('101', '2', '5', 'fractura', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('102', '2', '6', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('103', '2', '7', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('104', '2', '8', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('105', '2', '9', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('106', '2', '10', 'obturado', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('107', '2', '11', 'implante', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('108', '2', '12', 'endodoncia', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('109', '2', '13', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('110', '2', '14', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('111', '2', '15', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('112', '2', '16', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('113', '2', '17', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('114', '2', '18', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('115', '2', '19', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('116', '2', '20', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('117', '2', '21', 'implante', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('118', '2', '22', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('119', '2', '23', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('120', '2', '24', 'fractura', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('121', '2', '25', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('122', '2', '26', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('123', '2', '27', 'implante', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('124', '2', '28', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('125', '2', '29', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('126', '2', '30', 'endodoncia', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('127', '2', '31', 'corona', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('128', '2', '32', 'sano', NULL, '2026-08-16 09:12:36');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('129', '4', '1', 'implante', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('130', '4', '2', 'endodoncia', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('131', '4', '3', 'endodoncia', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('132', '4', '4', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('133', '4', '5', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('134', '4', '6', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('135', '4', '7', 'caries', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('136', '4', '8', 'caries', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('137', '4', '9', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('138', '4', '10', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('139', '4', '11', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('140', '4', '12', 'fractura', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('141', '4', '13', 'corona', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('142', '4', '14', 'obturado', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('143', '4', '15', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('144', '4', '16', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('145', '4', '17', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('146', '4', '18', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('147', '4', '19', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('148', '4', '20', 'endodoncia', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('149', '4', '21', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('150', '4', '22', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('151', '4', '23', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('152', '4', '24', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('153', '4', '25', 'caries', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('154', '4', '26', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('155', '4', '27', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('156', '4', '28', 'sano', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('157', '4', '29', 'implante', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('158', '4', '30', 'corona', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('159', '4', '31', 'fractura', NULL, '2026-08-16 09:13:24');
INSERT INTO `odontograma` (`id`, `paciente_id`, `numero_diente`, `condicion`, `notas`, `fecha_actualizacion`) VALUES ('160', '4', '32', 'sano', NULL, '2026-08-16 09:13:24');

-- Estructura de `ordenes_compra`
DROP TABLE IF EXISTS `ordenes_compra`;
CREATE TABLE `ordenes_compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `folio` varchar(20) NOT NULL,
  `proveedor` varchar(150) NOT NULL,
  `fecha_entrega_estimada` date DEFAULT NULL,
  `estado` enum('pendiente','aprobada','recibida','cancelada') NOT NULL DEFAULT 'pendiente',
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `notas` text DEFAULT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `folio` (`folio`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `ordenes_compra`
INSERT INTO `ordenes_compra` (`id`, `folio`, `proveedor`, `fecha_entrega_estimada`, `estado`, `total`, `notas`, `fecha_creacion`) VALUES ('1', 'OC-2026-001', 'Hector', '2026-08-06', 'recibida', '60.00', NULL, '2026-08-01 12:42:16');
INSERT INTO `ordenes_compra` (`id`, `folio`, `proveedor`, `fecha_entrega_estimada`, `estado`, `total`, `notas`, `fecha_creacion`) VALUES ('2', 'OC-2026-002', 'Samuel', '2026-08-08', 'cancelada', '300.00', NULL, '2026-08-01 15:12:27');
INSERT INTO `ordenes_compra` (`id`, `folio`, `proveedor`, `fecha_entrega_estimada`, `estado`, `total`, `notas`, `fecha_creacion`) VALUES ('3', 'OC-2026-003', 'Pedro', '2026-08-01', 'recibida', '200.00', NULL, '2026-08-01 15:46:41');
INSERT INTO `ordenes_compra` (`id`, `folio`, `proveedor`, `fecha_entrega_estimada`, `estado`, `total`, `notas`, `fecha_creacion`) VALUES ('4', 'OC-2026-004', 'Cepillos adc', '2026-08-12', 'recibida', '250.00', NULL, '2026-08-01 19:14:56');
INSERT INTO `ordenes_compra` (`id`, `folio`, `proveedor`, `fecha_entrega_estimada`, `estado`, `total`, `notas`, `fecha_creacion`) VALUES ('5', 'OC-2026-005', 'Destal', '2026-08-01', 'recibida', '25.00', NULL, '2026-08-01 19:17:58');
INSERT INTO `ordenes_compra` (`id`, `folio`, `proveedor`, `fecha_entrega_estimada`, `estado`, `total`, `notas`, `fecha_creacion`) VALUES ('6', 'OC-2026-006', 'Pastas addc', '2026-08-12', 'recibida', '150.00', NULL, '2026-08-01 19:20:48');
INSERT INTO `ordenes_compra` (`id`, `folio`, `proveedor`, `fecha_entrega_estimada`, `estado`, `total`, `notas`, `fecha_creacion`) VALUES ('7', 'OC-2026-007', 'Pedro', '2026-08-24', 'recibida', '10.00', NULL, '2026-08-21 13:26:58');
INSERT INTO `ordenes_compra` (`id`, `folio`, `proveedor`, `fecha_entrega_estimada`, `estado`, `total`, `notas`, `fecha_creacion`) VALUES ('8', 'OC-2026-008', 'Raul', '2026-08-21', 'recibida', '400.00', NULL, '2026-08-21 13:31:00');

-- Estructura de `ordenes_compra_lineas`
DROP TABLE IF EXISTS `ordenes_compra_lineas`;
CREATE TABLE `ordenes_compra_lineas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orden_id` int(11) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `orden_id` (`orden_id`),
  KEY `producto_id` (`producto_id`),
  CONSTRAINT `ordenes_compra_lineas_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `ordenes_compra` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ordenes_compra_lineas_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `ordenes_compra_lineas`
INSERT INTO `ordenes_compra_lineas` (`id`, `orden_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES ('1', '1', '1', '6', '10.00');
INSERT INTO `ordenes_compra_lineas` (`id`, `orden_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES ('2', '2', '1', '30', '10.00');
INSERT INTO `ordenes_compra_lineas` (`id`, `orden_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES ('3', '3', '2', '10', '20.00');
INSERT INTO `ordenes_compra_lineas` (`id`, `orden_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES ('4', '4', '4', '10', '25.00');
INSERT INTO `ordenes_compra_lineas` (`id`, `orden_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES ('5', '5', '4', '1', '25.00');
INSERT INTO `ordenes_compra_lineas` (`id`, `orden_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES ('6', '6', '5', '5', '30.00');
INSERT INTO `ordenes_compra_lineas` (`id`, `orden_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES ('7', '7', '1', '1', '10.00');
INSERT INTO `ordenes_compra_lineas` (`id`, `orden_id`, `producto_id`, `cantidad`, `precio_unitario`) VALUES ('8', '8', '3', '2', '200.00');

-- Estructura de `pacientes`
DROP TABLE IF EXISTS `pacientes`;
CREATE TABLE `pacientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `telefono` varchar(30) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `tipo_sangre` varchar(5) DEFAULT NULL,
  `alergias` text DEFAULT NULL,
  `contacto_emergencia` varchar(200) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `genero` enum('Femenino','Masculino','Otro') DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `pacientes_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `pacientes`
INSERT INTO `pacientes` (`id`, `usuario_id`, `telefono`, `direccion`, `tipo_sangre`, `alergias`, `contacto_emergencia`, `fecha_nacimiento`, `genero`) VALUES ('1', '2', '375 126 1789', NULL, 'O-', 'Ibuprofeno', NULL, '2012-07-09', 'Masculino');
INSERT INTO `pacientes` (`id`, `usuario_id`, `telefono`, `direccion`, `tipo_sangre`, `alergias`, `contacto_emergencia`, `fecha_nacimiento`, `genero`) VALUES ('2', '3', '3751599632', 'Obreros', 'O+', 'Penicilina', 'Jose 375 147 1475', '2017-09-29', 'Femenino');
INSERT INTO `pacientes` (`id`, `usuario_id`, `telefono`, `direccion`, `tipo_sangre`, `alergias`, `contacto_emergencia`, `fecha_nacimiento`, `genero`) VALUES ('3', '4', '3751261692', 'Obresos', NULL, NULL, NULL, '2026-08-20', 'Masculino');
INSERT INTO `pacientes` (`id`, `usuario_id`, `telefono`, `direccion`, `tipo_sangre`, `alergias`, `contacto_emergencia`, `fecha_nacimiento`, `genero`) VALUES ('4', '5', '3751598787', 'Municipal', NULL, NULL, NULL, '2026-08-20', 'Femenino');
INSERT INTO `pacientes` (`id`, `usuario_id`, `telefono`, `direccion`, `tipo_sangre`, `alergias`, `contacto_emergencia`, `fecha_nacimiento`, `genero`) VALUES ('5', '6', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- Estructura de `pagos`
DROP TABLE IF EXISTS `pagos`;
CREATE TABLE `pagos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `tratamiento_id` int(11) DEFAULT NULL,
  `cita_id` int(11) DEFAULT NULL,
  `monto` decimal(10,2) NOT NULL,
  `metodo` enum('efectivo','tarjeta','transferencia') NOT NULL DEFAULT 'efectivo',
  `fecha_pago` date NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `tratamiento_id` (`tratamiento_id`),
  KEY `cita_id` (`cita_id`),
  CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pagos_ibfk_2` FOREIGN KEY (`tratamiento_id`) REFERENCES `tratamientos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pagos_ibfk_3` FOREIGN KEY (`cita_id`) REFERENCES `citas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `pagos`
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('1', '1', '1', NULL, '200.00', 'efectivo', '2026-07-31', '2026-07-29 17:08:22');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('2', '1', '1', NULL, '200.00', 'efectivo', '2026-07-31', '2026-07-31 20:36:32');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('3', '1', NULL, '1', '400.00', 'efectivo', '2026-07-31', '2026-07-31 20:37:10');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('4', '4', NULL, '4', '4000.00', 'efectivo', '2026-08-06', '2026-08-06 13:06:28');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('5', '5', NULL, '8', '350.00', 'efectivo', '2026-08-14', '2026-08-14 17:55:51');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('6', '5', '2', NULL, '250.00', 'efectivo', '2026-08-14', '2026-08-14 18:29:10');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('7', '1', '3', NULL, '150.00', 'efectivo', '2026-08-14', '2026-08-14 19:22:02');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('8', '3', '4', NULL, '250.00', 'efectivo', '2026-08-17', '2026-08-14 19:23:19');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('9', '1', '5', NULL, '150.00', 'efectivo', '2026-08-18', '2026-08-14 19:27:47');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('11', '2', '8', NULL, '150.00', 'efectivo', '2026-08-17', '2026-08-14 20:45:10');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('16', '5', '17', NULL, '250.00', 'efectivo', '2026-08-21', '2026-08-20 22:28:27');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('17', '5', '17', NULL, '200.00', 'efectivo', '2026-08-20', '2026-08-20 22:46:51');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('18', '1', NULL, '2', '5000.00', 'efectivo', '2026-08-20', '2026-08-20 22:47:23');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('19', '4', NULL, '5', '400.00', 'efectivo', '2026-08-20', '2026-08-20 22:50:38');
INSERT INTO `pagos` (`id`, `paciente_id`, `tratamiento_id`, `cita_id`, `monto`, `metodo`, `fecha_pago`, `fecha_creacion`) VALUES ('20', '4', NULL, '11', '400.00', 'efectivo', '2026-08-21', '2026-08-21 13:12:42');

-- Estructura de `productos`
DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `codigo` varchar(30) NOT NULL,
  `categoria` enum('Restauracion','Anestesia','Ortodoncia','Descartables','Esterilizacion','Instrumentos') NOT NULL,
  `marca` varchar(100) DEFAULT NULL,
  `unidad` varchar(50) DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `stock_minimo` int(11) NOT NULL DEFAULT 0,
  `stock_maximo` int(11) DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL DEFAULT 0.00,
  `vencimiento` date DEFAULT NULL,
  `proveedor` varchar(150) DEFAULT NULL,
  `ubicacion` varchar(100) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `productos`
INSERT INTO `productos` (`id`, `nombre`, `codigo`, `categoria`, `marca`, `unidad`, `stock`, `stock_minimo`, `stock_maximo`, `precio`, `vencimiento`, `proveedor`, `ubicacion`, `activo`, `fecha_creacion`) VALUES ('1', 'Resina', 'RES-001', 'Restauracion', NULL, 'Cajas 10', '1', '0', '50', '10.00', '2026-08-01', NULL, NULL, '1', '2026-08-01 12:39:56');
INSERT INTO `productos` (`id`, `nombre`, `codigo`, `categoria`, `marca`, `unidad`, `stock`, `stock_minimo`, `stock_maximo`, `precio`, `vencimiento`, `proveedor`, `ubicacion`, `activo`, `fecha_creacion`) VALUES ('2', 'Ligas', 'RES-002', 'Instrumentos', NULL, 'Caja 11', '0', '0', '20', '20.00', '2027-02-28', NULL, NULL, '1', '2026-08-01 15:46:09');
INSERT INTO `productos` (`id`, `nombre`, `codigo`, `categoria`, `marca`, `unidad`, `stock`, `stock_minimo`, `stock_maximo`, `precio`, `vencimiento`, `proveedor`, `ubicacion`, `activo`, `fecha_creacion`) VALUES ('3', 'Bracket', 'RES-003', 'Ortodoncia', NULL, 'CAJA 10', '0', '0', '30', '200.00', NULL, NULL, NULL, '1', '2026-08-01 15:54:49');
INSERT INTO `productos` (`id`, `nombre`, `codigo`, `categoria`, `marca`, `unidad`, `stock`, `stock_minimo`, `stock_maximo`, `precio`, `vencimiento`, `proveedor`, `ubicacion`, `activo`, `fecha_creacion`) VALUES ('4', 'Cepillos', 'RES-004', 'Descartables', 'cOLGATE', NULL, '20', '0', '15', '25.00', NULL, NULL, NULL, '1', '2026-08-01 19:13:22');
INSERT INTO `productos` (`id`, `nombre`, `codigo`, `categoria`, `marca`, `unidad`, `stock`, `stock_minimo`, `stock_maximo`, `precio`, `vencimiento`, `proveedor`, `ubicacion`, `activo`, `fecha_creacion`) VALUES ('5', 'Pasta', 'RES-005', 'Descartables', NULL, NULL, '0', '0', '10', '30.00', '2026-08-01', NULL, NULL, '1', '2026-08-01 19:20:00');
INSERT INTO `productos` (`id`, `nombre`, `codigo`, `categoria`, `marca`, `unidad`, `stock`, `stock_minimo`, `stock_maximo`, `precio`, `vencimiento`, `proveedor`, `ubicacion`, `activo`, `fecha_creacion`) VALUES ('6', 'Penicilina', 'RES_06', 'Restauracion', NULL, '10', '20', '10', '20', '30.00', '2026-09-30', NULL, NULL, '1', '2026-08-21 13:21:05');

-- Estructura de `receta_medicamentos`
DROP TABLE IF EXISTS `receta_medicamentos`;
CREATE TABLE `receta_medicamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `receta_id` int(11) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `concentracion` varchar(50) DEFAULT NULL,
  `forma` varchar(50) DEFAULT NULL,
  `dosis` varchar(100) NOT NULL,
  `frecuencia` varchar(50) DEFAULT NULL,
  `duracion` varchar(50) DEFAULT NULL,
  `instrucciones` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `receta_id` (`receta_id`),
  CONSTRAINT `receta_medicamentos_ibfk_1` FOREIGN KEY (`receta_id`) REFERENCES `recetas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `receta_medicamentos`
INSERT INTO `receta_medicamentos` (`id`, `receta_id`, `nombre`, `concentracion`, `forma`, `dosis`, `frecuencia`, `duracion`, `instrucciones`) VALUES ('1', '1', 'Penicilina', '500 mg', 'Tabletas', '1', 'Cada 6 horas', '5 días', 'No alcohol');
INSERT INTO `receta_medicamentos` (`id`, `receta_id`, `nombre`, `concentracion`, `forma`, `dosis`, `frecuencia`, `duracion`, `instrucciones`) VALUES ('2', '2', 'AMPECILINA', '250', 'Tabletas', '1', 'Cada 6 horas', '3 días', NULL);
INSERT INTO `receta_medicamentos` (`id`, `receta_id`, `nombre`, `concentracion`, `forma`, `dosis`, `frecuencia`, `duracion`, `instrucciones`) VALUES ('3', '3', 'Penicilina', '500 mg', 'Tabletas', '1', 'Cada 6 horas', '7 días', NULL);
INSERT INTO `receta_medicamentos` (`id`, `receta_id`, `nombre`, `concentracion`, `forma`, `dosis`, `frecuencia`, `duracion`, `instrucciones`) VALUES ('4', '4', 'Amoxiliclina', NULL, 'Tabletas', '1', 'Cada 6 horas', '10 días', NULL);

-- Estructura de `recetas`
DROP TABLE IF EXISTS `recetas`;
CREATE TABLE `recetas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `folio` varchar(20) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `diagnostico` varchar(255) NOT NULL,
  `motivo_consulta` varchar(255) DEFAULT NULL,
  `indicaciones` text DEFAULT NULL,
  `proxima_cita` date DEFAULT NULL,
  `estado` enum('activa','completada','vencida') NOT NULL DEFAULT 'activa',
  `fecha` date NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `folio` (`folio`),
  KEY `paciente_id` (`paciente_id`),
  KEY `doctor_id` (`doctor_id`),
  CONSTRAINT `recetas_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recetas_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `recetas`
INSERT INTO `recetas` (`id`, `folio`, `paciente_id`, `doctor_id`, `diagnostico`, `motivo_consulta`, `indicaciones`, `proxima_cita`, `estado`, `fecha`, `fecha_creacion`) VALUES ('1', 'RX-2026-0001', '1', '1', 'Prueba', NULL, NULL, NULL, 'completada', '2026-08-02', '2026-08-01 20:26:28');
INSERT INTO `recetas` (`id`, `folio`, `paciente_id`, `doctor_id`, `diagnostico`, `motivo_consulta`, `indicaciones`, `proxima_cita`, `estado`, `fecha`, `fecha_creacion`) VALUES ('2', 'RX-2026-0002', '2', '1', 'prueba', NULL, NULL, '2026-08-07', 'completada', '2026-08-02', '2026-08-01 20:27:46');
INSERT INTO `recetas` (`id`, `folio`, `paciente_id`, `doctor_id`, `diagnostico`, `motivo_consulta`, `indicaciones`, `proxima_cita`, `estado`, `fecha`, `fecha_creacion`) VALUES ('3', 'RX-2026-0003', '1', '1', 'Retiro de muela', 'Dolor intenso', NULL, NULL, 'completada', '2026-08-21', '2026-08-21 13:34:21');
INSERT INTO `recetas` (`id`, `folio`, `paciente_id`, `doctor_id`, `diagnostico`, `motivo_consulta`, `indicaciones`, `proxima_cita`, `estado`, `fecha`, `fecha_creacion`) VALUES ('4', 'RX-2026-0004', '5', '1', 'sas', 'Dolor', NULL, NULL, 'activa', '2026-08-21', '2026-08-21 17:46:37');

-- Estructura de `recordatorios`
DROP TABLE IF EXISTS `recordatorios`;
CREATE TABLE `recordatorios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cita_id` int(11) NOT NULL,
  `regla_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `canal` enum('whatsapp','email','whatsapp_email') NOT NULL,
  `mensaje_enviado` text NOT NULL,
  `fecha_programada` datetime NOT NULL,
  `estado` enum('enviado','fallido') NOT NULL,
  `fecha_envio` datetime NOT NULL,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `cita_id` (`cita_id`),
  KEY `regla_id` (`regla_id`),
  KEY `paciente_id` (`paciente_id`),
  CONSTRAINT `recordatorios_ibfk_1` FOREIGN KEY (`cita_id`) REFERENCES `citas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recordatorios_ibfk_2` FOREIGN KEY (`regla_id`) REFERENCES `reglas_recordatorio` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recordatorios_ibfk_3` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `recordatorios`
INSERT INTO `recordatorios` (`id`, `cita_id`, `regla_id`, `paciente_id`, `canal`, `mensaje_enviado`, `fecha_programada`, `estado`, `fecha_envio`, `fecha_creacion`) VALUES ('1', '2', '1', '1', 'email', 'Hola Erick, le recordamos que tiene una cita el 2026-08-10 a las 09:30 para Blanquamiento dental.', '2026-08-09 09:30:00', 'enviado', '2026-08-02 08:43:01', '2026-08-02 08:43:01');
INSERT INTO `recordatorios` (`id`, `cita_id`, `regla_id`, `paciente_id`, `canal`, `mensaje_enviado`, `fecha_programada`, `estado`, `fecha_envio`, `fecha_creacion`) VALUES ('2', '2', '2', '1', 'email', 'Hola Erick, le recordamos que tiene una cita el 2026-08-10 a las 09:30 para Blanquamiento dental.', '2026-08-10 08:30:00', 'enviado', '2026-08-02 09:11:03', '2026-08-02 09:11:03');
INSERT INTO `recordatorios` (`id`, `cita_id`, `regla_id`, `paciente_id`, `canal`, `mensaje_enviado`, `fecha_programada`, `estado`, `fecha_envio`, `fecha_creacion`) VALUES ('3', '8', '1', '5', 'email', 'Hola Alejandro, le recordamos que tiene una cita el 2026-08-18 a las 08:00 para Implante dental.', '2026-08-17 08:00:00', 'enviado', '2026-08-16 12:23:41', '2026-08-16 12:23:41');

-- Estructura de `reglas_recordatorio`
DROP TABLE IF EXISTS `reglas_recordatorio`;
CREATE TABLE `reglas_recordatorio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `timing` enum('antes','despues') NOT NULL DEFAULT 'antes',
  `horas` int(11) NOT NULL DEFAULT 24,
  `canal` enum('whatsapp','email','whatsapp_email') NOT NULL DEFAULT 'email',
  `aplica_a` enum('todas','confirmadas','pendientes') NOT NULL DEFAULT 'todas',
  `mensaje` text NOT NULL,
  `activa` tinyint(1) NOT NULL DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `reglas_recordatorio`
INSERT INTO `reglas_recordatorio` (`id`, `nombre`, `descripcion`, `timing`, `horas`, `canal`, `aplica_a`, `mensaje`, `activa`, `fecha_creacion`) VALUES ('1', 'Recordatorio 24 hrs.', 'Recuerda 24 hrs antres de la cita', 'antes', '24', 'email', 'todas', 'Hola {{nombre}}, le recordamos que tiene una cita el {{fecha}} a las {{hora}} para {{tratamiento}}.', '1', '2026-08-02 08:41:55');
INSERT INTO `reglas_recordatorio` (`id`, `nombre`, `descripcion`, `timing`, `horas`, `canal`, `aplica_a`, `mensaje`, `activa`, `fecha_creacion`) VALUES ('2', 'Recordatorio 1 hrs antes', 'Recordatorio 1 hrs  antes', 'antes', '1', 'email', 'todas', 'Hola {{nombre}}, le recordamos que tiene una cita el {{fecha}} a las {{hora}} para {{tratamiento}}.', '1', '2026-08-02 08:46:19');
INSERT INTO `reglas_recordatorio` (`id`, `nombre`, `descripcion`, `timing`, `horas`, `canal`, `aplica_a`, `mensaje`, `activa`, `fecha_creacion`) VALUES ('3', 'prueba', NULL, 'antes', '22', 'email', 'todas', 'Hola {{nombre}}, le recordamos que tiene una cita el {{fecha}} a las {{hora}} para {{tratamiento}}.', '1', '2026-08-02 09:10:41');

-- Estructura de `servicios`
DROP TABLE IF EXISTS `servicios`;
CREATE TABLE `servicios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `categoria` enum('Preventivo','Ortodoncia','Restaurativo','Estetico','Cirugia') DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL DEFAULT 0.00,
  `duracion_min` int(11) NOT NULL DEFAULT 30,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `servicios`
INSERT INTO `servicios` (`id`, `nombre`, `categoria`, `descripcion`, `precio`, `duracion_min`, `activo`) VALUES ('1', 'Blanquamiento dental', 'Preventivo', '', '400.00', '30', '1');
INSERT INTO `servicios` (`id`, `nombre`, `categoria`, `descripcion`, `precio`, `duracion_min`, `activo`) VALUES ('2', 'Implante dental', 'Restaurativo', 'Carilla de porcelana para mejorar estética dental', '350.00', '60', '1');

-- Estructura de `tokens_recuperacion`
DROP TABLE IF EXISTS `tokens_recuperacion`;
CREATE TABLE `tokens_recuperacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expira_en` datetime NOT NULL,
  `usado` tinyint(1) NOT NULL DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `tokens_recuperacion_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `tokens_recuperacion`
INSERT INTO `tokens_recuperacion` (`id`, `usuario_id`, `token`, `expira_en`, `usado`, `creado_en`) VALUES ('3', '6', 'b7b9000163eb4fea46a39ab09a08994d873a6ac67c56a83cc4e96a6538bf277f', '2026-08-14 07:18:53', '0', '2026-08-13 22:18:53');

-- Estructura de `tratamientos`
DROP TABLE IF EXISTS `tratamientos`;
CREATE TABLE `tratamientos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `categoria` enum('Preventivo','Ortodoncia','Restaurativo','Estetico','Cirugia') DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  `diagnostico` text DEFAULT NULL,
  `notas` text DEFAULT NULL,
  `sesiones_totales` int(11) NOT NULL DEFAULT 1,
  `sesiones_completadas` int(11) NOT NULL DEFAULT 0,
  `fecha_inicio` date NOT NULL,
  `fecha_fin_estimada` date DEFAULT NULL,
  `costo_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `estado` enum('activo','completado','cancelado') NOT NULL DEFAULT 'activo',
  PRIMARY KEY (`id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `doctor_id` (`doctor_id`),
  CONSTRAINT `tratamientos_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `pacientes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tratamientos_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctores` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `tratamientos`
INSERT INTO `tratamientos` (`id`, `paciente_id`, `doctor_id`, `nombre`, `categoria`, `descripcion`, `diagnostico`, `notas`, `sesiones_totales`, `sesiones_completadas`, `fecha_inicio`, `fecha_fin_estimada`, `costo_total`, `estado`) VALUES ('1', '1', '1', 'Blanquamiento dental', 'Preventivo', '', 'Blanquear dientes', '', '1', '0', '2026-07-31', NULL, '400.00', 'cancelado');
INSERT INTO `tratamientos` (`id`, `paciente_id`, `doctor_id`, `nombre`, `categoria`, `descripcion`, `diagnostico`, `notas`, `sesiones_totales`, `sesiones_completadas`, `fecha_inicio`, `fecha_fin_estimada`, `costo_total`, `estado`) VALUES ('2', '5', '1', 'Blanquamiento dental', 'Preventivo', '', 'Blanquear', '', '1', '0', '2026-08-14', NULL, '400.00', 'cancelado');
INSERT INTO `tratamientos` (`id`, `paciente_id`, `doctor_id`, `nombre`, `categoria`, `descripcion`, `diagnostico`, `notas`, `sesiones_totales`, `sesiones_completadas`, `fecha_inicio`, `fecha_fin_estimada`, `costo_total`, `estado`) VALUES ('3', '1', '1', 'Blanquamiento dental', 'Preventivo', '', 'aa', '', '1', '0', '2026-08-14', NULL, '400.00', 'cancelado');
INSERT INTO `tratamientos` (`id`, `paciente_id`, `doctor_id`, `nombre`, `categoria`, `descripcion`, `diagnostico`, `notas`, `sesiones_totales`, `sesiones_completadas`, `fecha_inicio`, `fecha_fin_estimada`, `costo_total`, `estado`) VALUES ('4', '3', '1', 'Blanquamiento dental', 'Preventivo', '', 'xs', '', '1', '0', '2026-08-17', NULL, '400.00', 'cancelado');
INSERT INTO `tratamientos` (`id`, `paciente_id`, `doctor_id`, `nombre`, `categoria`, `descripcion`, `diagnostico`, `notas`, `sesiones_totales`, `sesiones_completadas`, `fecha_inicio`, `fecha_fin_estimada`, `costo_total`, `estado`) VALUES ('5', '1', '1', 'Implante dental', 'Restaurativo', 'Carilla de porcelana para mejorar estética dental', 'zz', '', '1', '0', '2026-08-18', NULL, '350.00', 'cancelado');
INSERT INTO `tratamientos` (`id`, `paciente_id`, `doctor_id`, `nombre`, `categoria`, `descripcion`, `diagnostico`, `notas`, `sesiones_totales`, `sesiones_completadas`, `fecha_inicio`, `fecha_fin_estimada`, `costo_total`, `estado`) VALUES ('8', '2', '1', 'Implante dental', 'Restaurativo', 'Carilla de porcelana para mejorar estética dental', 'ss', '', '1', '1', '2026-08-17', NULL, '350.00', 'cancelado');
INSERT INTO `tratamientos` (`id`, `paciente_id`, `doctor_id`, `nombre`, `categoria`, `descripcion`, `diagnostico`, `notas`, `sesiones_totales`, `sesiones_completadas`, `fecha_inicio`, `fecha_fin_estimada`, `costo_total`, `estado`) VALUES ('11', '2', '1', 'Blanquamiento dental', 'Preventivo', '', 'aa', '', '1', '0', '2026-08-17', NULL, '400.00', 'cancelado');
INSERT INTO `tratamientos` (`id`, `paciente_id`, `doctor_id`, `nombre`, `categoria`, `descripcion`, `diagnostico`, `notas`, `sesiones_totales`, `sesiones_completadas`, `fecha_inicio`, `fecha_fin_estimada`, `costo_total`, `estado`) VALUES ('12', '5', '1', 'Blanquamiento dental', 'Preventivo', '', 'aa', '', '1', '0', '2026-08-19', NULL, '400.00', 'cancelado');
INSERT INTO `tratamientos` (`id`, `paciente_id`, `doctor_id`, `nombre`, `categoria`, `descripcion`, `diagnostico`, `notas`, `sesiones_totales`, `sesiones_completadas`, `fecha_inicio`, `fecha_fin_estimada`, `costo_total`, `estado`) VALUES ('17', '5', '1', 'Blanquamiento dental', 'Preventivo', '', 'pruba', '', '2', '0', '2026-08-21', NULL, '400.00', 'activo');
INSERT INTO `tratamientos` (`id`, `paciente_id`, `doctor_id`, `nombre`, `categoria`, `descripcion`, `diagnostico`, `notas`, `sesiones_totales`, `sesiones_completadas`, `fecha_inicio`, `fecha_fin_estimada`, `costo_total`, `estado`) VALUES ('18', '5', '1', 'Implante dental', 'Restaurativo', 'Carilla de porcelana para mejorar estética dental', 'jaja', '', '1', '0', '2026-08-24', NULL, '350.00', 'cancelado');

-- Estructura de `usuarios`
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `contrasenna` varchar(255) DEFAULT NULL,
  `rol` enum('doctor','paciente') NOT NULL DEFAULT 'paciente',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp(),
  `ultimo_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos de `usuarios`
INSERT INTO `usuarios` (`id`, `nombre`, `correo`, `contrasenna`, `rol`, `activo`, `fecha_creacion`, `ultimo_login`) VALUES ('1', 'Manuel Alejandro', 'manuelalex2020@gmail.com', '$2y$10$Yz5s4b/9sZY034fRkrd52uNHGkx9R0DVxODvOOVFjOyNF0HZldWBK', 'doctor', '1', '2026-07-29 17:01:22', '2026-09-03 21:26:44');
INSERT INTO `usuarios` (`id`, `nombre`, `correo`, `contrasenna`, `rol`, `activo`, `fecha_creacion`, `ultimo_login`) VALUES ('2', 'Erick', 'erick@gmail.com', '$2b$10$pB7QSsKhGbhsC1jdrqosq.KULAPQ2ChlYtHQNLmoD.T28Mg39PDdi', 'paciente', '1', '2026-07-29 17:01:24', '2026-08-21 18:24:10');
INSERT INTO `usuarios` (`id`, `nombre`, `correo`, `contrasenna`, `rol`, `activo`, `fecha_creacion`, `ultimo_login`) VALUES ('3', 'Maria', 'maria@gmail.com', '$2y$10$TQ0WQOXq1jxernr8qAgTjOmCq.TUf8foYbLPFZ2m9BTJxTJ/WIMyW', 'paciente', '1', '2026-07-29 17:06:26', '2026-08-19 20:41:06');
INSERT INTO `usuarios` (`id`, `nombre`, `correo`, `contrasenna`, `rol`, `activo`, `fecha_creacion`, `ultimo_login`) VALUES ('4', 'Hector', 'hector@gmail.com', NULL, 'paciente', '1', '2026-08-05 19:54:42', NULL);
INSERT INTO `usuarios` (`id`, `nombre`, `correo`, `contrasenna`, `rol`, `activo`, `fecha_creacion`, `ultimo_login`) VALUES ('5', 'Samanta', 'samanta@gmail.com', '$2y$10$rntDtRMP8n914wqafAYRbeIg6XTUBbAXZbzw1/ZU.g.EOjMQLN88W', 'paciente', '1', '2026-08-05 20:03:36', '2026-08-06 13:02:59');
INSERT INTO `usuarios` (`id`, `nombre`, `correo`, `contrasenna`, `rol`, `activo`, `fecha_creacion`, `ultimo_login`) VALUES ('6', 'Alejandro', 'manuel.plascencia4221@alumnos.udg.mx', '$2y$10$gUuRKLOLhOXrbRbe73TtnubyVjztmJdVEl1UI2vPBBLDg.b7hrwOe', 'paciente', '1', '2026-08-12 20:02:48', '2026-08-22 09:01:37');

SET FOREIGN_KEY_CHECKS=1;
